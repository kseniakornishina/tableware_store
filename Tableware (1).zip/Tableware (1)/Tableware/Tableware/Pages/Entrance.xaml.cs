﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tableware
{
    /// <summary>
    /// Логика взаимодействия для Entrance.xaml
    /// </summary>
    public partial class Entrance : Page
    {
        public Entrance()
        {
            InitializeComponent();
            ManageFrame.Menu.Items.Clear();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (UserInput.UserAuthentication(txbLogin.Text, pbxPassword.Password))
                ManageFrame.Frame.Navigate(new MainPage());
            else
                MessageBox.Show($"Были введены невеные данные {txbLogin.Text}, {pbxPassword.Password}");
        }

        private void TextBlock_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ManageFrame.Frame.Navigate(new Registration());
        }

        private void TextBlock_MouseEnter(object sender, MouseEventArgs e)
        {
            Label lable = (Label)sender;
            lable.Foreground = Brushes.LightBlue;

        }

        private void TextBlock_MouseLeave(object sender, MouseEventArgs e)
        {
            Label lable = (Label)sender;
            lable.Foreground = Brushes.Black;

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            ManageFrame.Frame.Navigate(new ProductСatalogPage1());
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            ManageFrame.Frame.Navigate(new Registration());
        }
    }
}
