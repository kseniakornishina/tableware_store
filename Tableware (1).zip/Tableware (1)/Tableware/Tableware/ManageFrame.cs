﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Collections;

namespace Tableware
{
    static class ManageFrame
    {
        public static Frame Frame { get; set; }
        public static ListBox Menu { get; set; }

    }
}
