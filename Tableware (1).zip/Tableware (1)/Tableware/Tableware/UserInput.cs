﻿using System;
using System.Configuration;
using DataManagementTools;
using System.Data.SqlClient;
namespace Tableware
{
    static class UserInput
    {
        public static User User { get; private set; }

        public static bool UserAuthentication(string login, string password)
        {
            ManageData manageData = new ManageData();
            SqlDataReader reader = manageData.SqlRequestReader($"select * from [User] where UserLogin = '{login}' and UserPassword = '{password}'");
            if(reader.Read())
            {
                User = new User();
                User.UserId = (int)reader["UseID"];
                User.UserSurname = (string)reader["UserSurname"];
                User.UserName = (string)reader["UserName"];
                User.UserPatronymic = (string)reader["UserPatronymic"];
                User.IDRole = (int)reader["UserRole"];
                return true;
            }
            return false;
        }
        
    }
}
